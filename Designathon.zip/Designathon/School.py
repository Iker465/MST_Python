from flask import Flask,render_template,request
import mysql.connector
user_dict={'admin':'1234','user':'5678'}
conn = mysql.connector.connect(host='localhost',user='root',password='',database='SMS')
mycursor=conn.cursor()
#create a flask application
app = Flask(__name__)

#Define the route 

@app.route('/')
def hello():
    return render_template('first.html')
@app.route('/employee')
def employee():
    return render_template('student.html')
@app.route('/login')
def login():
    return render_template('login.html')
@app.route('/home',methods=['POST'])
def home():
    uname=request.form['username']
    pwd=request.form['password']

    if uname not in user_dict:
        return render_template('login.html',msg='Invalid User')
    elif user_dict[uname] != pwd:
        return render_template('login.html',msg='Invalid Password')
    else:
        return render_template('home.html')
@app.route('/view')
def view():
    query="SELECT * FROM STUDENT"
    mycursor.execute(query)
    data=mycursor.fetchall()
    return render_template('view.html',sqldata=data)

@app.route('/search')
def searchpage():
    return render_template('search.html')

@app.route('/back')
def returnhome():
    return render_template('home.html')


@app.route('/searchresult',methods=['POST'])
def search():
    adm_no = request.form['ADMISSION_NO']
    query="SELECT * FROM STUDENT WHERE ADM_NO="+adm_no
    mycursor.execute(query)
    data=mycursor.fetchall()
    return render_template('view.html',sqldata=data)
   
@app.route('/add')
def add():
    return render_template('student.html')

@app.route('/read',methods=['POST'])
def read():
    adm_no = request.form['ADMISSION_NO']
    std_name = request.form['STUDENT_NAME']
    std_dob= request.form['STUDENT_DOB']
    stream = request.form['STREAM']
    cls = request.form['STUDENT_CLASS']
    cnt_no = request.form['CONTACT_NO']
    query = "INSERT INTO STUDENT(ADM_NO,STD_NAME,STD_DOB,STREAM,CONTACT_NO,STUD_CLS) VALUES (%s,%s,%s,%s,%s,%s)"
    data = (adm_no,std_name,std_dob,stream,cnt_no,cls)
    mycursor.execute(query,data)
    conn.commit()
    return render_template('student.html',msgdata='Added Successfully')

#Run the flask app
if __name__=='__main__':
    app.run(port=5002,debug = True)
